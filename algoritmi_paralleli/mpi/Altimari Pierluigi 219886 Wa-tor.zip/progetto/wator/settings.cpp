
//the number of updates
#define CYCLES 1000
//rows of the wator matrix
#define ROWS 150
//cols of the wator matrix
#define COLS 150
//energy required for a fish to reproduce
#define FISH_TRESHHOLD 1
//shark starting energy
#define START_ENERGY 9
//energy required for a shark to reproduce
#define SHARK_TRESHHOLD 10
//energy given to a shark after eating a fish
#define EAT_ENERGY 1
